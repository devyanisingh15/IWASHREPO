package com.example.loginactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class book extends AppCompatActivity {
    Spinner dropdown ;
    DatabaseHelper db;
    EditText et1,et2,et3,et4,et5;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_book );
        et1 = findViewById( R.id.bname );
        et2 = findViewById( R.id.bphone );
        et3 = findViewById( R.id.bsoc );
        et4 = findViewById( R.id.bflat );
        et5 = findViewById( R.id.bblock );
        button = findViewById( R.id.bookbtn );
        dropdown = findViewById( R.id.spinner1 );

        String[] items = new String[]{"2 Wheeler", "4 Wheeler"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);
        button.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        } );


    }

    public void addData() {
        boolean isInserted = db.insertData( et1.getText().toString(), et2.getText().toString(), et3.getText().toString(), et4.getText().toString(), et5.getText().toString() );
        if (isInserted == true)
            Toast.makeText( book.this, "Congratulations! You have successfully booked a wash", Toast.LENGTH_SHORT ).show();
        else
            Toast.makeText( book.this, "Try Again!", Toast.LENGTH_SHORT ).show();
    }

}
