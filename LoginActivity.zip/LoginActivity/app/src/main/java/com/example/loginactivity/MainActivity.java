package com.example.loginactivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.loginactivity.utils.PreferenceUtils;


public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    Button log_btn;
    Boolean session;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        b1 = findViewById( R.id.btn1 );
        b2 = findViewById( R.id.btn2 );
        b3 = findViewById( R.id.btn3 );
        log_btn = findViewById( R.id.logout );

        b1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this,book.class );
                startActivity( intent );
            }
        } );

        b2.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this,services.class );
                startActivity( intent );
            }
        } );

        b3.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MainActivity.this,washerdet.class );
                startActivity( intent );
            }
        } );

        log_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PreferenceUtils.savePassword( " ",MainActivity.this );
                PreferenceUtils.savePassword( " ",MainActivity.this );
                Intent intent = new Intent( MainActivity.this,Login.class );
                startActivity( intent );
                finish();

            }
        } );
    }

        }


