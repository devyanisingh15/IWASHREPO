package com.example.loginactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class washerdet extends AppCompatActivity {
    public EditText name;
    public Button btn;
    public TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_washerdet );

        name = findViewById( R.id.edit );
        btn = findViewById( R.id.qbtn );
        textView = findViewById( R.id.textresult );

        btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        } );
    }
}
